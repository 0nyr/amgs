package amgs;

public class App {
    public static void main( String[] args ) {

        System.out.println( "*** AMGS game launch ***" );
        Game game = new Game("AMGS");
        game.start();
        
    }
}
