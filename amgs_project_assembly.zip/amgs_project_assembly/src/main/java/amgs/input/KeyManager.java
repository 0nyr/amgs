package amgs.input;

import java.awt.event.*;

public class KeyManager implements KeyListener {
	
	private boolean[] keys;
	public boolean up, down, left, right;
	public boolean aUp, aDown, aLeft, aRight, closeCombatAtt;
	public boolean exit;
	public boolean fullscreen, normalscreen;
	
	public KeyManager() {
		keys = new boolean[256]; // linked to keycode
	}
	
	public void tick() {
		// movement direction
		up = keys[KeyEvent.VK_Z];
		down = keys[KeyEvent.VK_S];
		left = keys[KeyEvent.VK_Q];
		right = keys[KeyEvent.VK_D];

		// close combat attack 
		aUp = keys[KeyEvent.VK_UP];
		aDown = keys[KeyEvent.VK_DOWN];
		aLeft = keys[KeyEvent.VK_LEFT];
		aRight = keys[KeyEvent.VK_RIGHT];
		//closeCombatAtt = keys[KeyEvent.VK_SPACE];
		
		exit = keys[KeyEvent.VK_ESCAPE];

		fullscreen = keys[KeyEvent.VK_F11];
		normalscreen = keys[KeyEvent.VK_F12];
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		keys[e.getKeyCode()] = true;
	}
	
	@Override
	public void keyReleased(KeyEvent e) {
		keys[e.getKeyCode()] = false;
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		
	}
	
}


