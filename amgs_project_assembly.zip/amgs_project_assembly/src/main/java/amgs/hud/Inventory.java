package amgs.hud;

import amgs.*;

import java.awt.*;

public class Inventory {

    private Handler handler;
    
    public Inventory(Handler handler) {
        this.handler = handler;
    }

    public void tick() {

    }

    public void render(Graphics g) {

    }

}