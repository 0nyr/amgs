package amgs.items;

import amgs.*;

import java.util.*;
import java.awt.*;

public class ItemManager {

    // associates an Item to an Id
    public static Item[] idToitems = new Item[256];
    public Item gemmeItem;

    private void init() {
        gemmeItem = new GemmeItem(handler, 7);
    }

    // item manager
    private Handler handler;
    private ArrayList<Item> items;

    public ItemManager(Handler handler) {
        this.handler = handler;
        init();
        items = new ArrayList<Item>();
    }

    public void tick() {
        Iterator<Item> iterator = items.iterator();
        while(iterator.hasNext()) {
            Item item = iterator.next();
            item.tick();
            if(item.getCount() == Item.PICKED_UP) {
                iterator.remove();
            }
        }
    }

    public void render(Graphics g) { 
        for(Item item : items) {
            item.render(g);
        }
    }

    public void addItem(Item item) {
        items.add(item);
    }
    

}