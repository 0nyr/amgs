package amgs.items;

import amgs.*;

public class ItemManager {

    // associates an Item to an Id
    public static Item[] items = new Item[256];

    // item types
    public Item gemmeItem;

    private Handler handler;

    public ItemManager(Handler handler) {
        this.handler = handler;

        init();
    }

    private void init() {
        gemmeItem = new GemmeItem(handler, 7);
    }

}