package amgs.items;

import amgs.*;
import amgs.gfx.*;

import java.awt.*;

public class Item {

    public static final int PICKED_UP = -1;

    protected Handler handler;
    protected String name;
    protected final int id;
    protected Animation anim;
    protected int count;
    protected Rectangle bounds;

    public Item(Handler handler, String name, int id) {
        this.handler = handler;
        this.name = name;
        this.id = id;
        count = 1;

        ItemManager.items[id] = this;
    }
    
    public void tick() {
        if(anim == null) {
            return;
        }
        anim.tick();
    }

    public void render(Graphics g) {
        if(handler == null) {
            return;
        }
        g.drawImage(anim.getCurrentFrame(),
            (int)(bounds.x - handler.getGameCamera().getXOffset()), 
            (int)(bounds.y - handler.getGameCamera().getYOffset()), 
            bounds.width, bounds.height, null);
    }

    // GETTERS SETTERS
    public void setAnim(Animation anim) {
        this.anim = anim;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getName() {
        return name;
    }

    public void setBounds(Rectangle bounds) {
        this.bounds = bounds;
    }

    public void setPosition(int x, int y) {
        bounds.x = x;
        bounds.y = y;
    }

    public int getItemId() {
        return id;
    }

    // create copy of current item
    public Item createNew(int x, int y) {
        Item item = new Item(handler, name, id);
        item.setPosition(x, y);
        return item;
    }

}