package amgs.items;

import amgs.*;
import amgs.gfx.*;

import java.awt.*;

public class Item {

    public static final int PICKED_UP = -1;

    protected Handler handler;
    protected String name;
    protected final int id;
    protected Animation anim;
    protected int count;
    protected int x, y;
    protected Rectangle bounds;

    public Item(Handler handler, String name, int id) {
        this.handler = handler;
        this.name = name;
        this.id = id;
        count = 1;
        bounds = new Rectangle();

        ItemManager.idToitems[id] = this;
    }
    
    public void tick() {
        if(anim == null) {
            return;
        }
        anim.tick();
        // check if picked
        if(handler.getWorld().getPlayer()
            .getCollisionBounds(0f, 0f).intersects(bounds)) {
            count = PICKED_UP;
        }
    }

    public void render(Graphics g) {
        if(handler == null) {
            return;
        }
        if(anim == null) {
            return;
        }
        g.drawImage(anim.getCurrentFrame(),
            (int)(x - handler.getGameCamera().getXOffset()), 
            (int)(y - handler.getGameCamera().getYOffset()), 
            anim.getCurrentFrame().getWidth(), 
            anim.getCurrentFrame().getHeight(), null);
        testDisplayBounds(g);
    }

    private void testDisplayBounds(Graphics g) {
		if(Constants.isTest) { 
            g.setColor(Color.blue);
            g.fillRect(
                (int)(bounds.x - handler.getGameCamera().getXOffset()),
                (int)(bounds.y - handler.getGameCamera().getYOffset()),
                bounds.width, bounds.height);
		}
	}

    // GETTERS SETTERS
    public void setAnim(Animation anim) {
        this.anim = anim;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getName() {
        return name;
    }

    public void setBounds(Rectangle bounds) {
        this.bounds = bounds;
    }

    public void setWidthHeight(int width, int height) {
        bounds.width = width;
        bounds.height = height;
    }


    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getItemId() {
        return id;
    }

    // create copy of current item
    public Item createNew(int x, int y) {
        Item item = new Item(handler, name, id);
        item.setAnim(anim);
        item.setBounds(new Rectangle(
            (int)(Constants.TILE_WIDTH*(6f/16f) + x), 
            (int)(Constants.TILE_HEIGHT*(3f/16f) + y), 
            (int)(Constants.TILE_WIDTH*(6f/16f)), 
            (int)(Constants.TILE_HEIGHT*(10f/16f))
            ));
        item.setPosition(x, y);
        return item;
    }

}