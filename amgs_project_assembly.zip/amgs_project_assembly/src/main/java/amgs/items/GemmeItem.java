package amgs.items;

import amgs.*;
import amgs.gfx.*;

public class GemmeItem extends Item {

    public GemmeItem(Handler handler, int id) {
        super(handler, "gemme", id);
        anim = new Animation(500, Assets.smallGemme);
    }

}