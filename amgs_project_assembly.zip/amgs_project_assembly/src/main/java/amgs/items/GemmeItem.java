package amgs.items;

import amgs.*;
import amgs.gfx.*;

import java.awt.*;

public class GemmeItem extends Item {

    public GemmeItem(Handler handler, int id) {
        super(handler, "gemme", id);
        setAnim(new Animation(200, Assets.smallGemme));
        setBounds(new Rectangle(4, 3, 6, 8));
    }

}