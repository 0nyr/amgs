package amgs.background.procedure;

import amgs.*;

public class LevelGenerator {

    public Handler handler;

    public LevelGenerator(Handler handler) {
        this.handler = handler;
    }

}