package amgs.ui;

public interface ClickListener {

    public void onClick();

}