package amgs.utils;

import java.io.IOException;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;

public class Utils {

    public static String loadFileAsString(String path) {

        String content = "";
        boolean isPathOk = false;
        Path pathJar;

        // try to get path
        try {
            // UNIX - the URL.toString() methods appends a "file:" that must be removed
            pathJar = Paths.get(Utils.class.getResource(path).toString()
                .replaceAll("file:","").replace("/C:", "/c"));
            isPathOk = true;
            content = Files.readString( pathJar, StandardCharsets.UTF_8);
        } catch(Exception e) {
            System.out.println("Unix file path failed");
            e.printStackTrace();
        }
        
        return content;
    }

    public static int parseInt(String number) {
        int convertedInt;
        try {
            convertedInt = Integer.parseInt(number);
        } catch(NumberFormatException e) {
            e.printStackTrace();
            convertedInt = 0;
        }
        return convertedInt;
    }
}