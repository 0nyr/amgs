package amgs.utils;

import java.io.*;
import java.nio.charset.*;
//import org.apache.commons.io.IOUtils;

public class Utils {

    public static String loadFileAsString(String path) {

        String content = "";
        InputStream inputStream;

        // try to get path
        try {
            // UNIX - the URL.toString() methods appends a "file:" that must be removed
            /*pathJar = Paths.get(Utils.class.getResource(path).toString()
                .replaceAll("file:","").replace("/C:", "/c").replaceAll("jar:",""));*/
            //pathJar = Paths.get("res", "worlds", "world1.txt");
            //pathJar = Paths.get(Utils.class.getResource("/res/worlds/world1.txt").toExternalForm().replaceAll("file:","").replaceAll("jar:",""));
            /*urlPath = Utils.class.getResource(path);
            try {
                uriPath = urlPath.toURI();
                pathJar = Paths.get(uriPath);
                content = Files.readString( pathJar, StandardCharsets.UTF_8);
            } catch(Exception e) {
                e.printStackTrace();
                System.exit(0);
            }*/
            //content = IOUtils.toString(input, StandardCharsets.UTF_8.name());
            inputStream = Utils.class.getResourceAsStream(path);
            StringBuilder textBuilder = new StringBuilder();
            try (Reader reader = new BufferedReader(new InputStreamReader
            (inputStream, Charset.forName(StandardCharsets.UTF_8.name())))) {
                int c = 0;
                while ((c = reader.read()) != -1) {
                    textBuilder.append((char) c);
                }
            }
            content = textBuilder.toString();
            
        } catch(Exception e) {
            System.out.println("path generation failed in amgs.utils.Utils.java");
            e.printStackTrace();
        }
        
        return content;
    }

    public static int parseInt(String number) {
        int convertedInt;
        try {
            convertedInt = Integer.parseInt(number);
        } catch(NumberFormatException e) {
            e.printStackTrace();
            convertedInt = 0;
        }
        return convertedInt;
    }
}