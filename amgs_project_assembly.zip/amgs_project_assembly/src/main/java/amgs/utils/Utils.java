package amgs.utils;

import java.io.*;
import java.nio.charset.*;
//import org.apache.commons.io.IOUtils;

public class Utils {

    public static String loadFileAsString(String path) {
        String content = "";
        // try to get path
        // WARN: cannot use Utils.class.getRessource(), not supported with .jar files
        try {
            // get file as InputStream and convert it to String with StringBuilder
            // more info: https://www.baeldung.com/convert-input-stream-to-string#java
            InputStream inputStream = Utils.class.getResourceAsStream(path);
            StringBuilder textBuilder = new StringBuilder();
            try (Reader reader = new BufferedReader(new InputStreamReader
            (inputStream, Charset.forName(StandardCharsets.UTF_8.name())))) {
                int c = 0;
                while ((c = reader.read()) != -1) {
                    textBuilder.append((char) c);
                }
            }
            content = textBuilder.toString();
            
        } catch(Exception e) {
            System.out.println("path generation failed in amgs.utils.Utils.java");
            e.printStackTrace();
        }
        
        return content;
    }

    public static int parseInt(String number) {
        int convertedInt;
        try {
            convertedInt = Integer.parseInt(number);
        } catch(NumberFormatException e) {
            e.printStackTrace();
            convertedInt = 0;
        }
        return convertedInt;
    }
}