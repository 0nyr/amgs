package amgs.entities.stationary;

import amgs.*;
import amgs.entities.*;

public abstract class StationaryEntity extends Entity {

    public StationaryEntity(Handler handler, float x, float y, int width, int height) {
        super(handler, x, y, width, height);
    }

}