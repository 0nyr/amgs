﻿The font file in this archive was created by Andrew Tyler www.AndrewTyler.net and font@andrewtyler.net

Use at 12 or 24 px size with anti-alising off for best results.




